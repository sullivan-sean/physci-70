import storage

storage.remount("/", False)
