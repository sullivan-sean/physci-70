class Motor {
  public:
    Motor(int _fwd_pin, int _bwd_pin):
      fwd_pin(_fwd_pin), bwd_pin(_bwd_pin) {};

    void initialize() {
      pinMode(fwd_pin, OUTPUT);
      pinMode(bwd_pin, OUTPUT);
    }

    void forward() {
      digitalWrite(bwd_pin, HIGH);
      digitalWrite(fwd_pin, LOW);
    }

    void backward() {
      digitalWrite(fwd_pin, HIGH);
      digitalWrite(bwd_pin, LOW);
    }

    void stop() {
      digitalWrite(fwd_pin, HIGH);
      digitalWrite(bwd_pin, HIGH);
    }

    int fwd_pin;
    int bwd_pin;
};
